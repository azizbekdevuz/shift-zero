import { useEffect, useMemo, useRef, useState } from 'react'
import { ArrowRight, FastForward, HardHat, PenLine, Play, Rewind, RotateCcw, SkipForward } from 'lucide-react'
import { Scene, type Brief, type RouteUi } from './Scene'
import { LANGS, dict, type Dict, type Lang } from './i18n'
import { ASSET_KINDS, TEAM_DECLARED_TRIPO, useAssetStatuses } from './TripoAsset'
import {
  ALLOWED,
  SAMPLE,
  WALK_SPEED,
  changedKinds,
  parseHash,
  setAfter,
  walkPlan,
  type AnchorId,
  type Handover,
  type Kind,
  type RouteId,
  type Shift,
} from './handover'
import { CreatePanel } from './Create'
import { Ending, ReceivePanel, describe, fromOf } from './Receive'
import './index.css'

type Mode = 'receive' | 'create'

function LangToggle({ lang, onChange }: { lang: Lang; onChange: (l: Lang) => void }) {
  return (
    <div className="seg seg-sm" role="group" aria-label="Language">
      {LANGS.map((l) => (
        <button key={l.id} className={lang === l.id ? 'on' : ''} aria-pressed={lang === l.id} onClick={() => onChange(l.id)}>
          {l.label}
        </button>
      ))}
    </div>
  )
}

function Sources({ t }: { t: Dict }) {
  const status = useAssetStatuses()
  const glbCount = ASSET_KINDS.filter((k) => status[k] === 'glb').length
  return (
    <details className="sources">
      <summary>{t.sources}</summary>
      <ul>
        {ASSET_KINDS.map((k) => (
          <li key={k}>
            <span>{t.assets[k]}</span>
            <em className={status[k] === 'glb' ? 'glb' : ''}>
              {status[k] === 'checking' ? t.checking : status[k] === 'glb' ? (TEAM_DECLARED_TRIPO ? t.glbTripo : t.glb) : t.procedural}
            </em>
          </li>
        ))}
      </ul>
      <p>
        {ASSET_KINDS.some((k) => status[k] === 'checking')
          ? t.checking
          : glbCount === 0
            ? t.sourcesNone
            : t.sourcesSome(glbCount, ASSET_KINDS.length, TEAM_DECLARED_TRIPO)}
      </p>
    </details>
  )
}

/** Starter draft for the creator: the sample scenario with editable, localized notes. */
const makeDraft = (t: Dict): Handover => ({
  from: '',
  changes: {
    pallet: { after: 'walkway', note: t.sampleNotes.pallet },
    barrier: { after: 'zone', note: t.sampleNotes.barrier },
    machine: { after: 'lane', note: t.sampleNotes.machine },
  },
})

/** True while the creator's draft still holds the untouched starter notes (in any language). */
const isPristine = (d: Handover) =>
  d.from === '' &&
  (Object.keys(d.changes) as Kind[]).every((k) => Object.values(dict).some((x) => x.sampleNotes[k] === d.changes[k]!.note))

const NO_ROUTES: RouteUi = { mode: 'off', chosen: null, walkKey: 0 }

export default function App() {
  const [lang, setLangState] = useState<Lang>('en')
  const t = dict[lang]
  // switching language never resets progress; an untouched starter draft just follows the language
  const setLang = (l: Lang) => {
    setLangState(l)
    setDraft((d) => (isPristine(d) ? makeDraft(dict[l]) : d))
  }

  // --- what the URL contains
  const [link, setLink] = useState(() => parseHash(location.hash))
  const [gift, setGift] = useState<Handover>(() => {
    const r = parseHash(location.hash)
    return r.status === 'ok' ? r.handover : SAMPLE
  })

  const [started, setStarted] = useState(false)
  const [mode, setMode] = useState<Mode>('receive')
  const [resetKey, setResetKey] = useState(0)
  const [shift, setShift] = useState<Shift>('previous')
  const [toast, setToast] = useState<number | null>(null)

  // --- cinematic handover (skippable, replayable): step 0 BEFORE · 1 NOW · 2 routes · 3 finished
  const [cine, setCine] = useState({ run: 0, on: false, step: 3 })

  // --- receive state
  const [found, setFound] = useState<Kind[]>([])
  const [focus, setFocus] = useState<Kind | null>(null)
  const [chosen, setChosen] = useState<RouteId | null>(null)
  const [walkKey, setWalkKey] = useState(0)
  const [walking, setWalking] = useState(false)
  const [attempts, setAttempts] = useState(0)
  const [passed, setPassed] = useState(false)
  const [dismissed, setDismissed] = useState(false)
  const walkTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)

  // --- create state
  const [draft, setDraft] = useState<Handover>(() => makeDraft(dict.en))
  const [selected, setSelected] = useState<Kind>('pallet')

  const create = mode === 'create'
  const handover = create ? draft : gift
  const kinds = useMemo(() => changedKinds(gift), [gift])
  const allFound = found.length === kinds.length
  const from = fromOf(gift, t)

  useEffect(() => {
    document.documentElement.lang = lang
  }, [lang])

  useEffect(() => {
    if (toast === null) return
    const id = setTimeout(() => setToast(null), 1800)
    return () => clearTimeout(id)
  }, [toast])

  useEffect(() => () => clearTimeout(walkTimer.current), [])

  // the cinematic sequence: a handful of timers, cleared on skip / replay / unmount
  useEffect(() => {
    if (!cine.on) return
    const ids = [
      setTimeout(() => {
        setShift('current')
        setCine((c) => ({ ...c, step: 1 }))
      }, 2800),
      setTimeout(() => setCine((c) => ({ ...c, step: 2 })), 6000),
      setTimeout(() => setCine((c) => ({ ...c, on: false, step: 3 })), 12200),
    ]
    return () => ids.forEach(clearTimeout)
  }, [cine.on, cine.run])

  const startCine = () => {
    setShift('previous')
    setCine((c) => ({ run: c.run + 1, on: true, step: 0 }))
  }
  const skipCine = () => {
    setShift('current')
    setCine((c) => ({ ...c, on: false, step: 3 }))
  }

  const resetReceive = () => {
    clearTimeout(walkTimer.current)
    setWalking(false)
    setFound([])
    setFocus(null)
    setChosen(null)
    setAttempts(0)
    setPassed(false)
    setDismissed(false)
    setToast(null)
    setShift('previous')
    setResetKey((k) => k + 1)
  }

  // open a pasted / edited gift link while the app is running
  useEffect(() => {
    const onHash = () => {
      const r = parseHash(location.hash)
      if (r.status === 'none') return
      setLink(r)
      if (r.status === 'ok') setGift(r.handover)
      setMode('receive')
      setStarted(false)
      setCine((c) => ({ ...c, on: false, step: 3 }))
      resetReceive()
    }
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])

  const enterMode = (m: Mode) => {
    setMode(m)
    resetReceive()
    if (m === 'create') {
      setCine((c) => ({ ...c, on: false, step: 3 }))
      setShift('current')
    } else startCine()
  }

  const enter = (m: Mode) => {
    setStarted(true)
    enterMode(m)
  }

  const watchSample = () => {
    setGift(SAMPLE)
    setLink({ status: 'none' })
    history.replaceState(null, '', location.pathname)
    enter('receive')
  }

  const switchMode = (m: Mode) => {
    if (m !== mode) enterMode(m)
  }

  const restart = () => {
    if (create) {
      setDraft(makeDraft(t))
      setSelected('pallet')
      setShift('current')
      setResetKey((k) => k + 1)
    } else {
      resetReceive()
      startCine()
    }
  }

  const select = (k: Kind) => {
    if (create) {
      setSelected(k)
      return
    }
    setFound((f) => (f.includes(k) ? f : [...f, k]))
    setFocus((cur) => (cur === k ? null : k))
  }

  const pickPad = (a: AnchorId) => {
    if (!ALLOWED[selected].includes(a)) return
    setDraft((d) => setAfter(d, selected, a))
    setShift('current')
  }

  const choose = (id: RouteId) => {
    if (walking) return
    const plan = walkPlan(gift, id, 'current')
    setChosen(id)
    setAttempts((n) => n + 1)
    setShift('current')
    setWalkKey((k) => k + 1)
    setWalking(true)
    clearTimeout(walkTimer.current)
    // the indicator walks the route (and stops at an obstruction); only then is the outcome shown
    walkTimer.current = setTimeout(() => {
      setWalking(false)
      if (!plan.blocked) setPassed(true)
    }, (plan.stop / WALK_SPEED) * 1000 + 900)
  }

  const previewAsReceiver = () => {
    setGift({ ...draft })
    setLink({ status: 'none' })
    setMode('receive')
    resetReceive()
    startCine()
  }

  const letter = chosen === 'west' ? 'A' : 'B'
  const inRoutePhase = !create && allFound && !passed
  const hint = cine.on
    ? t.cine[cine.step] ?? ''
    : create
      ? t.hintCreate
      : passed
        ? t.hintDone
        : inRoutePhase
          ? t.hintRoute
          : shift === 'previous'
            ? t.hintPrevious
            : t.hintCurrent

  const routeUi: RouteUi =
    create || !started
      ? NO_ROUTES
      : cine.on
        ? cine.step === 1
          ? NO_ROUTES
          : { mode: 'reveal', chosen: null, walkKey: 0 }
        : { mode: 'neutral', chosen, walkKey }

  const brief: Brief | null =
    !create && !cine.on && !chosen && focus && found.includes(focus) && shift === 'current' ? { kind: focus, from, ...describe(gift, focus, t) } : null

  const chip =
    !create && started && !cine.on && !passed && chosen ? (walking ? t.walking(letter) : t.chipBlocked(letter)) : null

  return (
    <div className="app">
      <header className="top">
        <div className="brand">
          <span className="logo" aria-hidden>
            <HardHat size={18} />
          </span>
          <div>
            <h1>{t.brand}</h1>
            <p>{t.tagline}</p>
          </div>
        </div>
        <div className="top-right">
          {started && (
            <div className="seg seg-sm" role="group" aria-label="Mode">
              <button className={!create ? 'on' : ''} aria-pressed={!create} onClick={() => switchMode('receive')}>
                <Play size={12} /> {t.navExperience}
              </button>
              <button className={create ? 'on' : ''} aria-pressed={create} onClick={() => switchMode('create')}>
                <PenLine size={12} /> {t.navCreate}
              </button>
            </div>
          )}
          <LangToggle lang={lang} onChange={setLang} />
          {started && (
            <button className="btn ghost" onClick={restart}>
              <RotateCcw size={15} /> {t.restart}
            </button>
          )}
        </div>
      </header>

      <main className={`main ${started ? '' : 'solo'}`}>
        <section className="viewport">
          <Scene
            handover={handover}
            shift={shift}
            mode={mode}
            markers={create ? (draft.changes[selected] ? [selected] : []) : cine.on ? [] : kinds}
            found={found}
            focus={focus}
            resetKey={resetKey}
            intro={!started}
            selectedKind={create ? selected : null}
            routeUi={routeUi}
            callouts={cine.on && cine.step === 1}
            brief={brief}
            onSelect={select}
            onPad={pickPad}
            onDecoy={() => setToast(Date.now())}
            t={t}
          />

          {started && (
            <div className={`shift-badge ${shift}`} key={shift} aria-live="polite">
              <b>{shift === 'previous' ? t.before : t.now}</b>
              <small>{shift === 'previous' ? t.beforeSub : t.nowSub}</small>
            </div>
          )}

          {chip && (
            <div className={`route-chip ${walking ? '' : 'bad'}`} role="status">
              {chip}
            </div>
          )}

          {started && !create && !cine.on && (
            <div className="hud hud-tl">
              <span className="hud-num">
                {found.length}/{kinds.length}
              </span>
              <span className="hud-label">{t.notesRead}</span>
            </div>
          )}

          {toast !== null && <div className="toast">{t.decoy}</div>}

          {started && (
            <div className="dock">
              <p className={`hint ${cine.on ? 'cine' : ''}`} key={cine.on ? `c${cine.step}` : 'h'}>
                {hint}
              </p>
              {cine.on ? (
                <button className="btn ghost skip" onClick={skipCine}>
                  <SkipForward size={15} /> {t.skip}
                </button>
              ) : (
                <div className="dock-row">
                  <div className="seg seg-lg" role="group" aria-label="Shift">
                    <button className={shift === 'previous' ? 'on' : ''} aria-pressed={shift === 'previous'} onClick={() => setShift('previous')}>
                      <Rewind size={15} /> {t.previous}
                    </button>
                    <button
                      className={`${shift === 'current' ? 'on' : ''} ${shift === 'previous' && !create && found.length === 0 ? 'nudge' : ''}`}
                      aria-pressed={shift === 'current'}
                      onClick={() => setShift('current')}
                    >
                      {t.current} <FastForward size={15} />
                    </button>
                  </div>
                  {!create && (
                    <button className="btn ghost replay" onClick={startCine}>
                      <RotateCcw size={15} /> {t.replay}
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          {!create && started && passed && chosen && !dismissed && (
            <Ending
              t={t}
              handover={gift}
              chosen={chosen}
              attempts={attempts}
              onReview={() => setDismissed(true)}
              onRestart={restart}
              onCreate={() => switchMode('create')}
            />
          )}

          {!started && (
            <div className="hero">
              <span className="eyebrow">{t.eyebrow}</span>
              <h2>{link.status === 'ok' ? t.giftWaiting(from) : t.heroHeadline}</h2>
              <p className="hero-sub">{link.status === 'ok' ? t.giftSub : t.heroSub}</p>

              {link.status === 'invalid' && (
                <div className="bad-link" role="alert">
                  <strong>{t.giftBadTitle}</strong>
                  <span>{t.giftBadBody}</span>
                </div>
              )}

              <div className="cta-row">
                <button className="btn primary xl" onClick={() => (link.status === 'ok' ? enter('receive') : watchSample())}>
                  {link.status === 'ok' ? t.ctaReceive : t.ctaWatch} <ArrowRight size={18} />
                </button>
                <button className="btn ghost xl" onClick={() => enter('create')}>
                  <PenLine size={18} /> {t.ctaCreate}
                </button>
              </div>
              <p className="hero-quote">{t.heroQuote}</p>
              <span className="meta">{t.disclaimer}</span>
            </div>
          )}
        </section>

        {started && (
          <aside className="panel">
            {create ? (
              <CreatePanel
                t={t}
                draft={draft}
                setDraft={setDraft}
                selected={selected}
                setSelected={setSelected}
                onPreview={previewAsReceiver}
              />
            ) : (
              <ReceivePanel
                t={t}
                handover={gift}
                found={found}
                focus={focus}
                chosen={chosen}
                attempts={attempts}
                passed={passed}
                walking={walking}
                onFocus={setFocus}
                onChoose={choose}
              />
            )}
            <Sources t={t} />
            <p className="fine">{t.disclaimer}</p>
          </aside>
        )}
      </main>
    </div>
  )
}

import { Component, Suspense, useEffect, useMemo, useSyncExternalStore, type ReactNode } from 'react'
import { useGLTF } from '@react-three/drei'
import * as THREE from 'three'

export type AssetKind = 'pallet' | 'barrier' | 'machine' | 'cone' | 'rack' | 'cabinet'
export type AssetStatus = 'checking' | 'procedural' | 'glb'
export type Size3 = readonly [number, number, number]

export const ASSET_KINDS: AssetKind[] = ['pallet', 'barrier', 'machine', 'cone', 'rack', 'cabinet']

/**
 * Credit flag. true = the team declares the GLBs in public/models were pre-generated in Tripo Studio
 * (the Sources panel then says so, and always says no live Tripo API is called).
 * Set to false if any of them did not come from Tripo. The app cannot verify provenance itself.
 */
export const TEAM_DECLARED_TRIPO = true

/** Yaw (radians) that aligns a GLB's long axis with our procedural fallback (long axis = +X). */
const GLB_YAW: Partial<Record<AssetKind, number>> = { machine: Math.PI / 2, cabinet: Math.PI / 2 }

/** File name (without .glb) in public/models for each kind. */
const MODEL_FILE: Record<AssetKind, string> = {
  pallet: 'pallet',
  barrier: 'barrier',
  machine: 'machine',
  cone: 'cone',
  rack: 'storage-rack',
  cabinet: 'tool-cabinet',
}
export const modelFile = (kind: AssetKind) => `${MODEL_FILE[kind]}.glb`
const modelUrl = (kind: AssetKind) => `${import.meta.env.BASE_URL}models/${modelFile(kind)}`
// Draco decoder is served locally (public/draco/gltf) so compressed GLBs also load offline.
const DRACO_PATH = `${import.meta.env.BASE_URL}draco/gltf/`

// --- Tiny external store: which optional GLBs actually exist ---------------
let snapshot = Object.fromEntries(ASSET_KINDS.map((k) => [k, 'checking'])) as Record<AssetKind, AssetStatus>
const listeners = new Set<() => void>()
const probed = new Set<AssetKind>()

function setStatus(kind: AssetKind, status: AssetStatus) {
  if (snapshot[kind] === status) return
  snapshot = { ...snapshot, [kind]: status }
  listeners.forEach((l) => l())
}

// Vite answers missing files with index.html (HTTP 200), so check the GLB magic bytes ("glTF").
function probe(kind: AssetKind) {
  if (probed.has(kind)) return
  probed.add(kind)
  fetch(modelUrl(kind))
    .then(async (res) => {
      if (!res.ok) return false
      const b = new Uint8Array(await res.arrayBuffer())
      return b.length > 12 && b[0] === 0x67 && b[1] === 0x6c && b[2] === 0x54 && b[3] === 0x46
    })
    .catch(() => false)
    .then((ok) => setStatus(kind, ok ? 'glb' : 'procedural'))
}

const subscribe = (cb: () => void) => {
  listeners.add(cb)
  return () => void listeners.delete(cb)
}

export function useAssetStatuses() {
  useEffect(() => ASSET_KINDS.forEach(probe), [])
  return useSyncExternalStore(subscribe, () => snapshot)
}

// --- Component ---------------------------------------------------------------
class GlbBoundary extends Component<
  { kind: AssetKind; fallback: ReactNode; children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false }
  static getDerivedStateFromError() {
    return { failed: true }
  }
  componentDidCatch() {
    setStatus(this.props.kind, 'procedural')
  }
  render() {
    return this.state.failed ? this.props.fallback : this.props.children
  }
}

/**
 * Hierarchy: <group scale=s> → <group position=-(centre, floor)> → yawed model.
 * The inner offset is in the model's own (unscaled) units, so the outer uniform scale fits the
 * model into `size`, and the result is centred on x/z with its base on y=0.
 */
function GlbModel({ kind, size }: { kind: AssetKind; size: Size3 }) {
  const { scene } = useGLTF(modelUrl(kind), DRACO_PATH)
  const { object, scale, offset } = useMemo(() => {
    const model = scene.clone(true)
    model.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        o.castShadow = true
        o.receiveShadow = true
      }
    })
    const object = new THREE.Group()
    object.add(model)
    object.rotation.y = GLB_YAW[kind] ?? 0
    object.updateWorldMatrix(true, true)
    const box = new THREE.Box3().setFromObject(object, true)
    const d = box.getSize(new THREE.Vector3())
    const c = box.getCenter(new THREE.Vector3())
    const ratios = [size[0] / d.x, size[1] / d.y, size[2] / d.z].filter((r) => Number.isFinite(r) && r > 0)
    const scale = ratios.length ? Math.min(...ratios) : 1
    return { object, scale, offset: new THREE.Vector3(-c.x, -box.min.y, -c.z) }
  }, [scene, size, kind])
  return (
    <group scale={scale}>
      <group position={offset}>
        <primitive object={object} />
      </group>
    </group>
  )
}

/**
 * Renders public/models/<kind>.glb (fitted to `size`) when that file exists and is a valid GLB.
 * Otherwise renders the procedural `children`. The app never depends on the GLB being present.
 */
export function TripoAsset({ kind, size, children }: { kind: AssetKind; size: Size3; children: ReactNode }) {
  const status = useAssetStatuses()[kind]
  if (status !== 'glb') return <>{children}</>
  return (
    <GlbBoundary kind={kind} fallback={children}>
      <Suspense fallback={children}>
        <GlbModel kind={kind} size={size} />
      </Suspense>
    </GlbBoundary>
  )
}
